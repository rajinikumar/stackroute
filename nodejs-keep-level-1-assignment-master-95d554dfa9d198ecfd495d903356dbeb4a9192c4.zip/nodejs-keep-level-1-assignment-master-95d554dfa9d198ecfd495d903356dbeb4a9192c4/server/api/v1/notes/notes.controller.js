const notesService =  require('./notes.services');

// handler to add note to database
const addNote = (userId, note) => {
  return notesService.addNote(userId, note);
};

// handler to get all notes from database
const getNotes = (userId) => {
  return notesService.getNotes(userId);
};

// handler to update note in database
const updateNote = (noteId, editedNote) => {
  return notesService.updateNote(noteId, editedNote);
};

module.exports = {
  addNote,
  getNotes,
  updateNote
}
