const router = require('express').Router();
const notesController = require('./notes.controller');

// api to add note to database
router.post('/', (req, res, next) => {
  let note = req.body;
  let userId = req.query.userId;
  try {
      notesController.addNote(userId, note).then((response) => {
      res.status(response.status).send(response.note);
    },
    (err) => {
      res.status(err.status).send(err);
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});

// api to get all notes from database
router.get('/', (req, res, next) => {
  let userId = req.query.userId;
  try {
    notesController.getNotes(userId).then((response) => {
      res.status(response.status).send(response.notes);
    },
    (err) => {
      res.status(err.status).send(err);
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});

// api to update note in database
router.put('/:noteId', (req, res, next) => {
  try {
    let userId = req.query.userId;
    let noteId = req.params.noteId;
    let editedNote =  req.body;
    notesController.updateNote(noteId, editedNote).then((response) => {
      res.status(response.status).send(response.updatedNote);
    },
    (err) => {
      res.status(err.status).send(err);
    });
  } catch (err) {
    res.send({message: 'Failed to complete request'})
  }
});

module.exports = router;
