let notesDao = require('./notes.dao');

// handler to add note to database
const addNote = (userId, note) => {
  return notesDao.addNote(userId, note);
};

// handler to get all notes from database
const getNotes = (userId) => {
  return notesDao.getNotes(userId);
};

// handler to update note in database
const updateNote = (noteId, editedNote) => {
  return notesDao.updateNote(noteId, editedNote);
};

module.exports = {
  addNote,
  getNotes,
  updateNote
}
