let noteModel = require('./notes.entity');
const uuidv1 = require('uuid/v1');

// handler to add note to database
const addNote = (userId, note) => {
  return new Promise((resolve, reject) => {
    let newNote = new noteModel();
    newNote.id = uuidv1();
    newNote.title = note.title;
    newNote.text = note.text;
    newNote.userId = userId;
    newNote.save((err, note) => {
      if(err) {
        reject({message: 'Internal Server Error', status: 500});
      } else {
        resolve({note: note, message: 'Note is added successfully', status:201});
      }
    });
});
};

// handler to get all notes from database
const getNotes = (userId) => {
  return new Promise((resolve, reject) => {
    noteModel.find({ userId: userId }, (err, notes) => {
      if (err) {
        reject({message: 'Internal Server Error', status: 500});
      } else {
        resolve({notes: notes, status:200});
      }
    });
  })
};

// handler to update note in database
const updateNote = (noteId, editedNote) => {
  return new Promise((resolve, reject) => {
    delete editedNote['_id'];
    delete editedNote['userId'];
    delete editedNote['createdOn'];
    delete editedNote['id'];
    editedNote['modifiedOn'] = new Date();
    noteModel.findOneAndUpdate({id: noteId}, editedNote, {new: true}, function(err, note) {
      if (err) {
        reject({message: 'Internal Server Error', status: 500});
      } else {
        resolve({updatedNote: note, message: 'Note is updated successfully', status: 200});
      }
    });
  });
};

module.exports = {
  addNote,
  getNotes,
  updateNote
}
