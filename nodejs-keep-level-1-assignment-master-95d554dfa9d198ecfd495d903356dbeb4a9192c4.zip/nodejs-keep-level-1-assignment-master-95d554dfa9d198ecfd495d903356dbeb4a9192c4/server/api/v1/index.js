const router = require('express').Router();

router.use('/notes', require('./notes'));
router.use('/users', require('./user'));

router.use((req, res) => {
    return res.status(404).send('Not Found');
})

module.exports = router;
