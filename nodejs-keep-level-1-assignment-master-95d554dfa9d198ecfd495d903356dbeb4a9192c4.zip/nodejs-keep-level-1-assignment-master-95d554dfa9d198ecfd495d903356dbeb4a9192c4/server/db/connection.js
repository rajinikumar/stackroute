let mongoose = require('mongoose');
const { dbConfig }  = require('../config').appConfig;

function createMongoConnection() {
  mongoose.connect(dbConfig.mongoUrl);
}

module.exports = {
  createMongoConnection
}