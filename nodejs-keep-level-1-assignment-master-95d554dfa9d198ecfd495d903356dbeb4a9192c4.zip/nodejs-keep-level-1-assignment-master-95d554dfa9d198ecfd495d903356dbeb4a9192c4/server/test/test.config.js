const register_user = {
	username:"SathyaNarayanaReddy",
	password:"password"
};

const reg_user_success_res = {
	user: {
		username:"SathyaNarayanaReddy"
	}
};

const error_messages = {
	user_already_exist : "username is already exist",
	incorrect_pwd : "Password is incorrect",
	incorrect_uname : "You are not registered user"
};

const login_with_wrong_pwd = {
	username: "SathyaNarayanaReddy",
	password: "password*"
};

const login_with_wrong_uname = {
	username: "Balachander",
	password: "password*"
};

module.exports = {
	register_user,
	reg_user_success_res,
	error_messages,
	login_with_wrong_pwd,
	login_with_wrong_uname
}

