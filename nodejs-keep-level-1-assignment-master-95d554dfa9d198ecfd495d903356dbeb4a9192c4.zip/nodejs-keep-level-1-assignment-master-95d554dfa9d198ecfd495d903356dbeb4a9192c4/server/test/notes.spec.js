const should = require('chai').should();
const request = require('supertest');
const app = require('../app');
const config = require('./test.config');

const USER_ID_1 = 'SathyaNarayanaReddy';
const USER_ID_2 = 'TEST123';

const note_1 = {
        title: "Payment Reminder",
        text: "Internet Bill"
}
const note_2 = {
	title: "Visiting Reminder",
	text: "Meet Balachander"
}

let NOTES_USER_ID_1= [];
let NOTES_USER_ID_2= [];

//  testsuite
describe('Testing to add a note', function()
{
  //  testcase
  it('Should handle a request to add a new note for user 1 ', function(done)
  {
    request(app)
    .post('/api/v1/notes?userId='+USER_ID_1)
    .send(note_1)
    .expect(201)
    .end((err, res) => {
      if (err) return done(err);
      (res.body.text).should.equal(note_1.text);
    }); 
	done();
  });

  //  testcase
  it('Should handle a request to add a new note for user 2', function(done)
  {
    request(app)
    .post('/api/v1/notes?userId='+USER_ID_2)
    .send(note_2)
    .expect(201)
    .end((err, res) => {
      if (err) return done(err);
      (res.body.text).should.equal(note_2.text);
	});
	done();
  });
});

//  testsuite
describe('Testing to get all notes', function()
{
  //  testcase
  it('Should handle a request to get all notes of a user 1', function(done)
  {
    request(app)
    .get('/api/v1/notes?userId='+USER_ID_1)
    .expect(200)
    .end((err, res) => {
      if (err) return done(err);
      NOTES_USER_ID_1 = res.body;
      (res.body[res.body.length-1].text).should.equal(note_1.text);
	  }); 
    done();
  });
  //  testcase
  it('Should handle a request to get all notes of a user 2', function(done)
  {
    request(app)
    .get('/api/v1/notes?userId='+USER_ID_2)
    .expect(200)
    .end((err, res) => {
      if (err) return done(err);
	  NOTES_USER_ID_2 = res.body;
      (res.body[res.body.length-1].text).should.equal(note_2.text);
    });
	done();
  });
  //  testcase
  it('Should handle a request to get notes of a user who has not created any note', function(done)
  {
    request(app)
    .get('/api/v1/notes?userId=Balu')
    .expect(200)
    .end((err, res) => {
      if (err) return done(err);
      (res.body.length).should.equal(0);
	});
	done();
  });
});

//  testsuite
describe('Testing to update a note', function()
{
  //  testcase
  it('Should handle a request to update a note by note id', function(done)
  {
    request(app)
    .put('/api/v1/notes/'+ NOTES_USER_ID_1[0].id)
    .send({state:"started"})
    .expect(200)
    .end((err, res) => {
      if (err) return done(err);
      (res.body.text).should.equal(NOTES_USER_ID_1[0].text);
   
	});
   done();
  });
});
