const should = require('chai').should();
const request = require('supertest');
const app = require('../app');
const config = require('./test.config');

//  testsuite
describe('Testing to register a user', function()
{
  //  testcase
  it('Should handle a request to register a user', function(done)
  {
    request(app)
    .post('/api/v1/users/register')
    .send(config.register_user)
    .expect(201)
    .end((err, res) => {
      if (err) return done(err);
      (res.body.user.userName).should.equal(config.reg_user_success_res.user.username);
    }); 
	done();
  });

  //  testcase
  it('Should handle a request to register a user multiple times with same username', function(done)
  {
    request(app)
    .post('/api/v1/users/register')
    .send(config.register_user)
    .expect(403)
    .end((err, res) => {
      if (err) return done(err);
      (res.body.message).should.equal(config.error_messages.user_already_exist);
    });
	done();
  });
});

//  testsuite
describe('Testing to login user', function()
{
  //  testcase
  it('Should handle a request to successfully login', function(done)
  {
    request(app)
    .post('/api/v1/users/login')
    .send(config.register_user)
    .expect(200)
    .end((err, res) => {
      if (err) return done(err);
      (res.body.user.userName).should.equal(config.register_user.username);
    });       
	done();
  });

  //  testcase
  it('Should handle a request to login with wrong password', function(done)
  {
    request(app)
    .post('/api/v1/users/login')
    .send(config.login_with_wrong_pwd)
    .expect(403)
    .end((err, res) => {
      if (err) return done(err);
      (res.body.message).should.equal(config.error_messages.incorrect_pwd);
    });
	done();
  });

  //  testcase
  it('Should handle a request to login with wrong username', function(done)
  {
    request(app)
    .post('/api/v1/users/login')
    .send(config.login_with_wrong_uname)
    .expect(403)
    .end((err, res) => {
      if (err) return done(err);
      (res.body.message).should.equal(config.error_messages.incorrect_uname);
    });
	done();
  });
});